@extends('layouts.app')

@section('content')
<h1>All Posts</h1>
<a href="{{ route('posts.create')}}" class="btn btn-primary mb-3">Create new post</a>

@foreach($temp as $post)
<div class="card mb-2">
    <div class="card-body">
        <h5>{{ $post->title }}</h5>
        <p>{{ Str::limit($post->content, 100) }}</p>
        <a href="{{ route('posts.show', $post->id)}}" class="btn btn-info">View</a>
        <a href="{{ route('posts.edit', $post->id)}}" class="btn btn-warning">Edit</a>
        <form action="{{ route('posts.destroy', $post->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger">Delete</button>

            </form>

    </div>
</div>

@endforeach

@endsection
